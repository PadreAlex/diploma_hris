import * as React from 'react';
import Box from '@mui/material/Box';

export function HiringFlowChart() {
  return <Box sx={{ display: 'flex', flexDirection: 'row', gap: 8, mt: 4 }}></Box>;
}

export default HiringFlowChart;
